# Slip-9
# Q.2 A) Write a Python program to display column-wise mean and median for SOCR-HeightWeight dataset.

import pandas as pd

# Load the dataset
data = pd.read_csv('SOCR-HeightWeight.csv')

# Display mean and median for each column
print("Column-wise Mean:")
print(data.mean())

print("\nColumn-wise Median:")
print(data.median())


# Slip-9
# Q.2 B) Write a Python program to compute the sum of Manhattan distance between all pairs of points.

import numpy as np
from scipy.spatial import distance_matrix

# Generate random points as example data
points = np.random.rand(10, 2)  # 10 points with 2 coordinates each

# Compute Manhattan distance between all pairs of points
manhattan_distances = distance_matrix(points, points, p=1)

# Compute the sum of all Manhattan distances
total_distance = np.sum(manhattan_distances)

print("Sum of Manhattan distances between all pairs of points:", total_distance)
