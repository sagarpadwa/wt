pip install numpy matplotlib seaborn

import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

# Set style for seaborn
sns.set(style="whitegrid")

# a. Generate a random array of 50 integers
data = np.random.randint(1, 100, size=50)

# Create a figure and axis for multiple plots
fig, axs = plt.subplots(2, 2, figsize=(12, 10))

# 1. Line Chart
axs[0, 0].plot(data, color='blue', marker='o', linestyle='-')
axs[0, 0].set_title('Line Chart of Random Integers', fontsize=16)
axs[0, 0].set_xlabel('Index', fontsize=12)
axs[0, 0].set_ylabel('Value', fontsize=12)
axs[0, 0].grid()

# 2. Scatter Plot
axs[0, 1].scatter(range(len(data)), data, color='red')
axs[0, 1].set_title('Scatter Plot of Random Integers', fontsize=16)
axs[0, 1].set_xlabel('Index', fontsize=12)
axs[0, 1].set_ylabel('Value', fontsize=12)
axs[0, 1].grid()

# 3. Histogram
axs[1, 0].hist(data, bins=10, color='green', edgecolor='black')
axs[1, 0].set_title('Histogram of Random Integers', fontsize=16)
axs[1, 0].set_xlabel('Value', fontsize=12)
axs[1, 0].set_ylabel('Frequency', fontsize=12)

# 4. Box Plot
sns.boxplot(data=data, ax=axs[1, 1], color='orange')
axs[1, 1].set_title('Box Plot of Random Integers', fontsize=16)
axs[1, 1].set_ylabel('Value', fontsize=12)

# Adjust layout
plt.tight_layout()
plt.show()

# b. Create two lists for subjects and marks
subjects = ['Math', 'Science', 'English', 'History', 'Art']
marks = [85, 92, 78, 88, 95]

# Bar chart for subjects and marks
plt.figure(figsize=(8, 6))
plt.bar(subjects, marks, color='purple')
plt.title('Marks Obtained in Subjects', fontsize=16)
plt.xlabel('Subjects', fontsize=12)
plt.ylabel('Marks', fontsize=12)
plt.ylim(0, 100)  # Set limit for y-axis
plt.grid(axis='y')

# Display the bar chart
plt.show()
