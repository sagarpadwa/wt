# Slip-21
# Q.2 A) Import dataset “iris.csv”. Write a Python program to create a Bar plot to get the frequency of the three species of the Iris data.

import pandas as pd
import matplotlib.pyplot as plt

# Load the iris dataset
iris_data = pd.read_csv('iris.csv')

# Count the frequency of each species
species_count = iris_data['species'].value_counts()

# Create a bar plot
plt.bar(species_count.index, species_count.values, color=['blue', 'green', 'red'])

# Labeling the plot
plt.title('Frequency of Iris Species')
plt.xlabel('Species')
plt.ylabel('Frequency')

# Display the plot
plt.show()


# Slip-21
# Q.2 B) Write a Python program to create a histogram of the three species of the Iris data.

import pandas as pd
import matplotlib.pyplot as plt

# Load the iris dataset
iris_data = pd.read_csv('iris.csv')

# Filter data for each species
setosa = iris_data[iris_data['species'] == 'setosa']
versicolor = iris_data[iris_data['species'] == 'versicolor']
virginica = iris_data[iris_data['species'] == 'virginica']

# Create histogram for each species
plt.hist(setosa['sepal_length'], alpha=0.5, label='Setosa', color='blue')
plt.hist(versicolor['sepal_length'], alpha=0.5, label='Versicolor', color='green')
plt.hist(virginica['sepal_length'], alpha=0.5, label='Virginica', color='red')

# Labeling the plot
plt.title('Histogram of Sepal Length for Iris Species')
plt.xlabel('Sepal Length')
plt.ylabel('Frequency')

# Add legend
plt.legend()

# Display the plot
plt.show()
