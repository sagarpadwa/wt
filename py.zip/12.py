# Slip-12
# Q.2 A) Write a Python program to create a graph to find the relationship between the petal length and petal width (Use iris.csv dataset).

import pandas as pd
import matplotlib.pyplot as plt

# Load the iris dataset
iris_data = pd.read_csv('iris.csv')

# Create scatter plot for Petal Length vs Petal Width
plt.scatter(iris_data['petal_length'], iris_data['petal_width'], c='blue')

# Labeling the plot
plt.title('Petal Length vs Petal Width')
plt.xlabel('Petal Length')
plt.ylabel('Petal Width')

# Display the plot
plt.show()


# Slip-12
# Q.2 B) Write a Python program to find the maximum and minimum value of a given flattened array.

import numpy as np

# Create a 2D array
array_2d = np.array([[4, 2, 9], [3, 8, 5], [7, 1, 6]])

# Flatten the array
flattened_array = array_2d.flatten()

# Find the maximum and minimum values
max_value = flattened_array.max()
min_value = flattened_array.min()

# Display the results
print("Flattened Array:", flattened_array)
print("Maximum Value:", max_value)
print("Minimum Value:", min_value)
