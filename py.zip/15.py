# Slip-15
# Q.2 A) Write a python program to create two lists, one representing subject names and the other representing marks obtained in those subjects.
# Display the data in a pie chart and bar chart.

import matplotlib.pyplot as plt

# Define subject names and marks
subjects = ['Math', 'Physics', 'Chemistry', 'Biology', 'English']
marks = [85, 78, 92, 88, 75]

# Create pie chart
plt.figure(figsize=(10, 5))

plt.subplot(1, 2, 1)
plt.pie(marks, labels=subjects, autopct='%1.1f%%', startangle=90)
plt.title('Marks Distribution in Pie Chart')

# Create bar chart
plt.subplot(1, 2, 2)
plt.bar(subjects, marks, color='orange')
plt.title('Marks Distribution in Bar Chart')
plt.xlabel('Subjects')
plt.ylabel('Marks')

# Display the plots
plt.tight_layout()
plt.show()


# Slip-15
# Q.2 B) Write a python program to create a data frame for students’ information such as name, graduation percentage, and age.
# Display the average age of students and the average of graduation percentage.

import pandas as pd

# Create a DataFrame for students
data = {
    'name': ['Alice', 'Bob', 'Charlie', 'David', 'Eva'],
    'graduation_percentage': [88, 76, 90, 85, 92],
    'age': [22, 23, 24, 22, 23]
}

df = pd.DataFrame(data)

# Display the original DataFrame
print("Student DataFrame:")
print(df)

# Calculate and display the average age and graduation percentage
average_age = df['age'].mean()
average_graduation_percentage = df['graduation_percentage'].mean()

print("\nAverage Age of Students:", average_age)
print("Average Graduation Percentage:", average_graduation_percentage)
