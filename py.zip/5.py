# Slip-5
# Q.2 A) Write a Python program for Handling Missing Value. Replace missing value of salary, age column with mean of that column (Use Data.csv file).

import pandas as pd

# Load the dataset
data = pd.read_csv('Data.csv')

# Display original data
print("Original Data:")
print(data)

# Replace missing values in 'salary' and 'age' columns with their mean
data['salary'].fillna(data['salary'].mean(), inplace=True)
data['age'].fillna(data['age'].mean(), inplace=True)

# Display data after handling missing values
print("\nData after handling missing values:")
print(data)


# Slip-5
# Q.2 B) Write a Python program to generate a line plot of name Vs salary.

import pandas as pd
import matplotlib.pyplot as plt

# Load the dataset
data = pd.read_csv('Data.csv')

# Generate line plot for Name vs Salary
plt.plot(data['name'], data['salary'], marker='o')

# Labeling the plot
plt.title("Name vs Salary")
plt.xlabel("Name")
plt.ylabel("Salary")
plt.xticks(rotation=45)

# Display the plot
plt.show()


# Slip-5
# Q.2 C) Download the heights and weights dataset and load the dataset from a given csv file. 
# Print the first, last 10 rows and random 20 rows, also display the shape of the dataset.

import pandas as pd

# Load the dataset
data = pd.read_csv('heights_weights.csv')

# Display first 10 rows
print("First 10 rows:")
print(data.head(10))

# Display last 10 rows
print("\nLast 10 rows:")
print(data.tail(10))

# Display 20 random rows
print("\nRandom 20 rows:")
print(data.sample(20))

# Display the shape of the dataset
print("\nShape of the dataset:", data.shape)
