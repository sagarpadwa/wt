# Slip-17
# Q.2 A) Write a Python program to create box plots to see how each feature (Sepal Length, Sepal Width, Petal Length, Petal Width) are distributed across the three species (Use iris.csv dataset).

import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

# Load the iris dataset
iris_data = pd.read_csv('iris.csv')

# Create box plots for each feature
plt.figure(figsize=(12, 8))

# Sepal Length
plt.subplot(2, 2, 1)
sns.boxplot(x='species', y='sepal_length', data=iris_data)
plt.title('Sepal Length Distribution')

# Sepal Width
plt.subplot(2, 2, 2)
sns.boxplot(x='species', y='sepal_width', data=iris_data)
plt.title('Sepal Width Distribution')

# Petal Length
plt.subplot(2, 2, 3)
sns.boxplot(x='species', y='petal_length', data=iris_data)
plt.title('Petal Length Distribution')

# Petal Width
plt.subplot(2, 2, 4)
sns.boxplot(x='species', y='petal_width', data=iris_data)
plt.title('Petal Width Distribution')

plt.tight_layout()
plt.show()


# Slip-17
# Q.2 B) Use the heights and weights dataset and load the dataset from a given csv file into a dataframe.
# Print the first, last 5 rows, and random 10 rows.

import pandas as pd

# Load the dataset
data = pd.read_csv('heights_weights.csv')

# Display the first 5 rows
print("First 5 rows:")
print(data.head(5))

# Display the last 5 rows
print("\nLast 5 rows:")
print(data.tail(5))

# Display 10 random rows
print("\nRandom 10 rows:")
print(data.sample(10))
