# Slip-6
# Q.2 A) Write a Python program to perform OneHot coding on the Country column (Use Data.csv).

import pandas as pd

# Load the dataset
data = pd.read_csv('Data.csv')

# Perform OneHot encoding on the Country column
one_hot_encoded_data = pd.get_dummies(data, columns=['Country'])

# Display the encoded data
print("Data after OneHot Encoding:")
print(one_hot_encoded_data)


# Slip-6
# Q.2 B) Write a Python program to perform Label encoding on the Purchased column (Use Data.csv).

from sklearn.preprocessing import LabelEncoder
import pandas as pd

# Load the dataset
data = pd.read_csv('Data.csv')

# Apply Label encoding on the Purchased column
label_encoder = LabelEncoder()
data['Purchased'] = label_encoder.fit_transform(data['Purchased'])

# Display the encoded data
print("Data after Label Encoding:")
print(data)
