# Slip-19
# Q.2) Write a Python program:
# 1. To create a dataframe containing columns name, age, and percentage. Add 10 rows to the dataframe. View the dataframe.
# 2. To print the shape, number of rows-columns, data types, feature names, and the description of the data.
# 3. To add 5 rows with duplicate values and missing values. Add a column 'remarks' with empty values. Display the data.

import pandas as pd

# Create initial dataframe with 10 rows
data = {
    'name': ['Alice', 'Bob', 'Charlie', 'David', 'Eva', 'Frank', 'George', 'Hannah', 'Ivy', 'Jack'],
    'age': [22, 23, 24, 22, 23, 24, 25, 22, 23, 24],
    'percentage': [88, 76, 90, 85, 92, 78, 80, 84, 89, 95]
}

df = pd.DataFrame(data)

# Display the initial dataframe
print("Initial DataFrame:")
print(df)

# Print the shape, number of rows-columns, data types, and description
print("\nShape of the DataFrame:", df.shape)
print("\nNumber of rows and columns:", df.shape[0], "rows,", df.shape[1], "columns")
print("\nData types of each column:")
print(df.dtypes)
print("\nFeature names:", df.columns.tolist())
print("\nDescription of the dataset:")
print(df.describe())

# Add 5 duplicate rows with missing values
additional_data = {
    'name': ['Bob', 'Charlie', 'David', None, 'Eva'],
    'age': [23, 24, 22, None, 23],
    'percentage': [76, 90, 85, 88, None]
}
additional_df = pd.DataFrame(additional_data)

# Concatenate to the original dataframe
df = pd.concat([df, additional_df], ignore_index=True)

# Add a 'remarks' column with empty values
df['remarks'] = [''] * len(df)

# Display the updated dataframe with duplicates and missing values
print("\nUpdated DataFrame with Duplicates, Missing Values, and Remarks Column:")
print(df)
