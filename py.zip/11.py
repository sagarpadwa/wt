# Slip-11
# Q.2 A) Generate a random array of 50 integers and display them using a line chart, scatter plot, histogram, and box plot. Apply appropriate color, labels, and styling options.

import numpy as np
import matplotlib.pyplot as plt

# Generate random array of 50 integers
random_data = np.random.randint(1, 100, 50)

# Line chart
plt.subplot(2, 2, 1)
plt.plot(random_data, marker='o', color='green')
plt.title('Line Chart')
plt.xlabel('Index')
plt.ylabel('Value')

# Scatter plot
plt.subplot(2, 2, 2)
plt.scatter(range(50), random_data, color='red')
plt.title('Scatter Plot')
plt.xlabel('Index')
plt.ylabel('Value')

# Histogram
plt.subplot(2, 2, 3)
plt.hist(random_data, bins=10, color='blue')
plt.title('Histogram')
plt.xlabel('Value')
plt.ylabel('Frequency')

# Box plot
plt.subplot(2, 2, 4)
plt.boxplot(random_data)
plt.title('Box Plot')

# Display the plots
plt.tight_layout()
plt.show()



# Slip-11
# Q.2 B) Write a Python program to create a data frame containing column name, salary, department. 
# Add 10 rows with some missing and duplicate values to the data frame. Also drop all null and empty values. Print the modified data frame.

import pandas as pd

# Create data frame with missing and duplicate values
data = {
    'name': ['Alice', 'Bob', 'Charlie', 'David', 'Alice', None, 'Frank', 'Eve', 'Grace', 'Hank'],
    'salary': [50000, 60000, None, 45000, 50000, 52000, None, 45000, 70000, 50000],
    'department': ['HR', 'IT', 'Finance', 'HR', 'HR', 'IT', 'IT', 'Finance', None, 'Finance']
}
df = pd.DataFrame(data)

# Display original data frame
print("Original Data Frame:")
print(df)

# Drop missing and duplicate values
df_cleaned = df.dropna().drop_duplicates()

# Display modified data frame
print("\nModified Data Frame:")
print(df_cleaned)
