# Slip-13
# Q.2 A) Write a Python NumPy program to compute the weighted average along the specified axis of a given flattened array.

import numpy as np

# Create a flattened array
flattened_array = np.array([1, 2, 3, 4, 5])

# Define corresponding weights
weights = np.array([0.1, 0.2, 0.3, 0.2, 0.2])

# Compute the weighted average
weighted_avg = np.average(flattened_array, weights=weights)

# Display the result
print("Weighted Average of the Array:", weighted_avg)


# Slip-13
# Q.2 B) Write a Python program to view basic statistical details of the data (Use advertising.csv).

import pandas as pd

# Load the advertising dataset
data = pd.read_csv('advertising.csv')

# Display basic statistical details
print("Basic Statistical Details:")
print(data.describe())
