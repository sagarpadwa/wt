import pandas as pd
from sklearn.preprocessing import LabelEncoder

# Step 1: Create a sample dataset and save it as 'data.csv'
data = {
    'country': ['USA', 'Canada', 'USA', 'Mexico', 'Canada', 'Mexico'],
    'purchased': ['Yes', 'No', 'Yes', 'No', 'Yes', 'No']
}

df = pd.DataFrame(data)
df.to_csv('data.csv', index=False)
print("Dataset created and saved as 'data.csv'.")

# Step 2: Load the dataset
df = pd.read_csv('data.csv')

# Apply One-Hot Encoding to the 'country' column
df_one_hot = pd.get_dummies(df, columns=['country'], drop_first=True)

# Step 3: Initialize the Label Encoder
label_encoder = LabelEncoder()

# Apply Label Encoding to the 'purchased' column
df_one_hot['purchased'] = label_encoder.fit_transform(df_one_hot['purchased'])

# Display the final DataFrame
print("\nOne-Hot Encoded DataFrame:")
print(df_one_hot)
