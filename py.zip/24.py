# Slip-24
# Q.2 A) Generate a random array of 50 integers and display them using a line chart, scatter plot, histogram, and box plot. Apply appropriate color, labels, and styling options.

import numpy as np
import matplotlib.pyplot as plt

# Generate random array of 50 integers
random_data = np.random.randint(1, 100, 50)

# Line chart
plt.subplot(2, 2, 1)
plt.plot(random_data, marker='o', color='green')
plt.title('Line Chart')
plt.xlabel('Index')
plt.ylabel('Value')

# Scatter plot
plt.subplot(2, 2, 2)
plt.scatter(range(50), random_data, color='red')
plt.title('Scatter Plot')
plt.xlabel('Index')
plt.ylabel('Value')

# Histogram
plt.subplot(2, 2, 3)
plt.hist(random_data, bins=10, color='blue')
plt.title('Histogram')
plt.xlabel('Value')
plt.ylabel('Frequency')

# Box plot
plt.subplot(2, 2, 4)
plt.boxplot(random_data)
plt.title('Box Plot')

# Display the plots
plt.tight_layout()
plt.show()


# Slip-24
# Q.2 B) Create two lists, one representing subject names and the other representing marks obtained in those subjects. Display the data in a pie chart.

import matplotlib.pyplot as plt

# Define subject names and marks
subjects = ['Math', 'Physics', 'Chemistry', 'Biology', 'English']
marks = [85, 78, 92, 88, 75]

# Create pie chart
plt.pie(marks, labels=subjects, autopct='%1.1f%%', startangle=90)
plt.title('Marks Distribution Across Subjects')
plt.show()


# Slip-24
# Q.1) Write a menu driven program to perform various file operations. Accept filename from user.
# a) Display type of file.
# b) Display last modification time of file.
# c) Display the size of file.
# d) Delete the file.

import os
import time

def file_operations(filename):
    if os.path.exists(filename):
        # a) Display type of file
        print(f"File Type: {os.path.splitext(filename)[1]}")
        
        # b) Display last modification time of file
        mod_time = os.path.getmtime(filename)
        print(f"Last Modification Time: {time.ctime(mod_time)}")
        
        # c) Display the size of file
        file_size = os.path.getsize(filename)
        print(f"File Size: {file_size} bytes")
        
        # d) Delete the file
        delete = input("Do you want to delete the file? (y/n): ")
        if delete.lower() == 'y':
            os.remove(filename)
            print(f"File {filename} deleted.")
        else:
            print(f"File {filename} not deleted.")
    else:
        print(f"The file {filename} does not exist.")

# Accept filename from user
filename = input("Enter the filename: ")
file_operations(filename)
