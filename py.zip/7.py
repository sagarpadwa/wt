# Slip-7
# Q.2) Write a Python program to perform the following task:
# Standardizing Data (transform them into a standard Gaussian distribution with a mean of 0 and a standard deviation of 1) (Use winequality-red.csv).

import pandas as pd
from sklearn.preprocessing import StandardScaler

# Load the dataset
data = pd.read_csv('winequality-red.csv')

# Select numerical columns for standardization
numeric_columns = data.select_dtypes(include=['float64', 'int64']).columns

# Initialize StandardScaler
scaler = StandardScaler()

# Standardize the data
data[numeric_columns] = scaler.fit_transform(data[numeric_columns])

# Display the standardized data
print("Standardized Data (First 5 Rows):")
print(data.head())
