import pandas as pd
from sklearn.preprocessing import LabelEncoder

# Create a sample dataset
data = {
    'country': ['USA', 'Canada', 'USA', 'Mexico', 'Canada', 'Mexico'],
    'purchased': ['Yes', 'No', 'Yes', 'No', 'Yes', 'No']
}

# Convert to DataFrame
df = pd.DataFrame(data)

# Save DataFrame to CSV
df.to_csv('data.csv', index=False)
print("Dataset created and saved as 'data.csv'.")

# Load the dataset
df = pd.read_csv('data.csv')

# Apply One-Hot Encoding to the 'country' column
df_one_hot = pd.get_dummies(df, columns=['country'], drop_first=True)

# Initialize the Label Encoder
label_encoder = LabelEncoder()

# Apply Label Encoding to the 'purchased' column
df_one_hot['purchased'] = label_encoder.fit_transform(df_one_hot['purchased'])

print("Final DataFrame after One-Hot and Label Encoding:")
print(df_one_hot)
