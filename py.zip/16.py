# Slip-16
# Q.2 A) Write a Python program to draw scatter plots to compare two features of the iris dataset (Use iris.csv).

import pandas as pd
import matplotlib.pyplot as plt

# Load the iris dataset
iris_data = pd.read_csv('iris.csv')

# Create scatter plot comparing Sepal Length and Sepal Width
plt.scatter(iris_data['sepal_length'], iris_data['sepal_width'], c='green')

# Labeling the plot
plt.title('Sepal Length vs Sepal Width')
plt.xlabel('Sepal Length')
plt.ylabel('Sepal Width')

# Display the plot
plt.show()


# Slip-16
# Q.2 B) Write a Python program to create a data frame containing columns name, age, salary, and department. 
# Add 10 rows to the data frame. View the data frame.

import pandas as pd

# Create a DataFrame with columns name, age, salary, and department
data = {
    'name': ['Alice', 'Bob', 'Charlie', 'David', 'Eva', 'Frank', 'George', 'Hannah', 'Ivy', 'Jack'],
    'age': [25, 28, 22, 30, 26, 24, 29, 27, 23, 31],
    'salary': [50000, 60000, 45000, 70000, 55000, 48000, 62000, 58000, 52000, 65000],
    'department': ['HR', 'Finance', 'IT', 'Marketing', 'HR', 'Admin', 'Finance', 'IT', 'HR', 'Marketing']
}

df = pd.DataFrame(data)

# View the data frame
print("DataFrame with Name, Age, Salary, and Department:")
print(df)
