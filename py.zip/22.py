# Slip-22
# Q.2 A) Write a Python program to perform rescaling (Normalized) the dataset using MinMaxScaler class (Use winequality-red.csv).

import pandas as pd
from sklearn.preprocessing import MinMaxScaler

# Load the winequality-red dataset
data = pd.read_csv('winequality-red.csv')

# Initialize MinMaxScaler
scaler = MinMaxScaler()

# Rescale the data
scaled_data = scaler.fit_transform(data)

# Convert scaled data back to a DataFrame
scaled_df = pd.DataFrame(scaled_data, columns=data.columns)

# Display the first 5 rows of the rescaled data
print("Rescaled Data (First 5 Rows):")
print(scaled_df.head())


# Slip-22
# Q.2 B) Write a Python program to perform Standardizing Data (transform them into a standard Gaussian distribution with a mean of 0 and a standard deviation of 1) (Use winequality-red.csv).

import pandas as pd
from sklearn.preprocessing import StandardScaler

# Load the winequality-red dataset
data = pd.read_csv('winequality-red.csv')

# Initialize StandardScaler
scaler = StandardScaler()

# Standardize the data
standardized_data = scaler.fit_transform(data)

# Convert standardized data back to a DataFrame
standardized_df = pd.DataFrame(standardized_data, columns=data.columns)

# Display the first 5 rows of the standardized data
print("Standardized Data (First 5 Rows):")
print(standardized_df.head())


# Slip-22
# Q.2 C) Write a Python program to perform Binarizing Data using the Binarizer class (Use winequality-red.csv).

import pandas as pd
from sklearn.preprocessing import Binarizer

# Load the winequality-red dataset
data = pd.read_csv('winequality-red.csv')

# Initialize Binarizer with a threshold of 5
binarizer = Binarizer(threshold=5)

# Binarize the data
binarized_data = binarizer.fit_transform(data)

# Convert binarized data back to a DataFrame
binarized_df = pd.DataFrame(binarized_data, columns=data.columns)

# Display the first 5 rows of the binarized data
print("Binarized Data (First 5 Rows):")
print(binarized_df.head())
