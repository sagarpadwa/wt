# Slip-18
# Q.2) Write a Python program to create a dataframe containing columns name, age, and percentage. Add 10 rows to the dataframe. View the dataframe.
# Add 5 rows with duplicate values and missing values. Add a column 'remarks' with empty values. Display the data.

import pandas as pd

# Create a DataFrame with 10 rows
data = {
    'name': ['Alice', 'Bob', 'Charlie', 'David', 'Eva', 'Bob', 'Charlie', 'George', None, 'Ivy'],
    'age': [22, 23, 24, 22, 23, 23, 24, 25, None, 23],
    'percentage': [88, 76, 90, 85, 92, 76, 90, 80, 88, None]
}

df = pd.DataFrame(data)

# Add a new column 'remarks' with empty values
df['remarks'] = [''] * len(df)

# Display the dataframe
print("DataFrame with Duplicates, Missing Values, and Remarks:")
print(df)
