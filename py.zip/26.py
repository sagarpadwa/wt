# Slip-26
# Q.2) Create a dataset data.csv having two categorical column (the country column, and the purchased column). Apply OneHot coding on Country column.

import pandas as pd

# Sample data
data = {'Country': ['France', 'Germany', 'Spain', 'France', 'Spain'],
        'Purchased': ['Yes', 'No', 'Yes', 'No', 'Yes']}

df = pd.DataFrame(data)

# Apply OneHot encoding on the Country column
one_hot_encoded_df = pd.get_dummies(df, columns=['Country'])

# Display the OneHot encoded dataframe
print("OneHot Encoded DataFrame:")
print(one_hot_encoded_df)


# Slip-26
# Q.2 B) Apply Label encoding on Purchased column (Use data.csv).

from sklearn.preprocessing import LabelEncoder
import pandas as pd

# Sample data
data = {'Country': ['France', 'Germany', 'Spain', 'France', 'Spain'],
        'Purchased': ['Yes', 'No', 'Yes', 'No', 'Yes']}

df = pd.DataFrame(data)

# Initialize LabelEncoder
label_encoder = LabelEncoder()

# Apply Label encoding on the Purchased column
df['Purchased'] = label_encoder.fit_transform(df['Purchased'])

# Display the Label encoded dataframe
print("Label Encoded DataFrame:")
print(df)
