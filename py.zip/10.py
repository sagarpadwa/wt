# Slip-10
# Q.2 A) Write a Python program to create a Pie plot to get the frequency of the three species of the Iris data (Use iris.csv).

import pandas as pd
import matplotlib.pyplot as plt

# Load the iris dataset
iris_data = pd.read_csv('iris.csv')

# Count the frequency of each species
species_count = iris_data['species'].value_counts()

# Create a pie chart
plt.pie(species_count, labels=species_count.index, autopct='%1.1f%%', startangle=90)
plt.title('Frequency of Iris Species')
plt.show()


# Slip-10
# Q.2 B) Write a Python program to view basic statistical details of the data (Use winequality-red.csv).

import pandas as pd

# Load the winequality-red dataset
wine_data = pd.read_csv('winequality-red.csv')

# Display basic statistical details
print("Basic Statistical Details:")
print(wine_data.describe())
