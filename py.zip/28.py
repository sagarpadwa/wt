import pandas as pd
import numpy as np

# Step 1: Create a DataFrame with columns name, age, and percentage
data = {
    'name': ['Alice', 'Bob', 'Charlie', 'David', 'Eva', 'Frank', 'Grace', 'Hannah', 'Ivy', 'Jack'],
    'age': [23, 34, 29, 40, 22, 31, 28, 37, 30, 25],
    'percentage': [88.5, 76.4, 92.3, 81.0, 95.5, 70.8, 85.0, 78.9, 89.7, 90.2]
}

df = pd.DataFrame(data)

# View the DataFrame
print("Initial DataFrame:")
print(df)

# Step 2: Print shape, number of rows-columns, data types, feature names, and description
print("\nShape of DataFrame:", df.shape)  # (number of rows, number of columns)
print("Number of Rows:", df.shape[0])
print("Number of Columns:", df.shape[1])
print("Data Types:")
print(df.dtypes)
print("Feature Names:", df.columns.tolist())
print("Description of Data:")
print(df.describe())

# Step 3: View basic statistical details of the data
print("\nBasic Statistical Details:")
print(df.describe())

# Step 4: Add 5 rows with duplicate and missing values, and a column 'remarks' with empty values
duplicate_data = {
    'name': ['Alice', 'Bob', 'Charlie', 'David', 'Eva'],
    'age': [23, 34, 29, 40, 22],
    'percentage': [88.5, 76.4, 92.3, 81.0, 95.5],
    'remarks': [None] * 5  # Empty remarks
}

# Create a DataFrame for duplicates
duplicates_df = pd.DataFrame(duplicate_data)

# Introduce missing values in 'age' column
duplicates_df.loc[2, 'age'] = np.nan  # Setting the age of Charlie to NaN

# Append duplicates to the original DataFrame
df = pd.concat([df, duplicates_df], ignore_index=True)

# Display the updated DataFrame
print("\nDataFrame after adding duplicates and missing values:")
print(df)
