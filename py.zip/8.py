# Slip-8
# Q.2 B) Create two lists, one representing subject names and the other representing marks obtained in those subjects. Display the data in a pie chart.

import matplotlib.pyplot as plt

# Define subject names and marks
subjects = ['Math', 'Physics', 'Chemistry', 'Biology', 'English']
marks = [85, 78, 92, 88, 75]

# Create pie chart
plt.pie(marks, labels=subjects, autopct='%1.1f%%', startangle=90)
plt.title('Marks Distribution Across Subjects')
plt.show()


# Slip-8
# Q.2 C) Write a Python program to perform the following task (Use winequality-red.csv):
# a) Describe the dataset
# b) Shape of the dataset
# c) Display the first 3 rows from the dataset

import pandas as pd

# Load the dataset
data = pd.read_csv('winequality-red.csv')

# Display description of the dataset
print("Description of the dataset:")
print(data.describe())

# Display the shape of the dataset
print("\nShape of the dataset:", data.shape)

# Display the first 3 rows
print("\nFirst 3 rows:")
print(data.head(3))
